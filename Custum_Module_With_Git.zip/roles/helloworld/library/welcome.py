DOCUMENTION = '''
---
module: welcome
Description: Return welcome message with engineer name.
'''

EXAMPLES='''
- name: Welcome to IBM
    name: "Praveen Kumar"
  register: get_welcome_status
'''


from ansible.module_utils.basic import AnsibleModule

def welcome(inputparam):
    try:
        eng_name = inputparam['name']
        return False, True, f"Welcome!, {eng_name}"
        # return False, True, "Welcome!, " + eng_name
    except Exception as ex:
        return True, False, ex.message


def main():
    fields = {
        "name": {"required": True, "type": str},
        "action": {
            "default": "welcome",
            "type": "str"
        },
    }

    choice_map = {
        "welcome": welcome,
    }

    module = AnsibleModule(argument_spec=fields)
    is_error, has_changed, result = choice_map.get(module.params['action'])(module.params)

    if not is_error:
        module.exit_json(changed=has_changed, meta=result)
    else:
        module.exit_json(msg="Error Encountered", meta=result)

if __name__=='__main__':
    main()